import React, { useState, useEffect } from "react";
import NavbarStyleOne from "@/components/Layouts/NavbarStyleOne";
import PageBannerStyle1 from "@/components/Common/PageBannerStyle1";
import FooterStyleOne from "@/components/Layouts/FooterStyleOne";
import BlogDetailsContent from "@/components/Blog/BlogDetailsContent";
import baseApiUrl from "@/utils/baseApiUrl";
import { useRouter } from "next/router";
import axios from "axios";

const BlogDetails = () => {
  const [blog, setBlog] = useState([]);
  const router = useRouter();
  const { slug } = router.query;
  useEffect(() => {
    const fetchBlog = async () => {
      const response = await axios.get(
        `${baseApiUrl}/api/blogs?filters[slug][$eq]=${slug}&populate=*`
      );
      setBlog(response.data.data);
    };

    fetchBlog();
  }, [slug]);

  return (
    <>
      <NavbarStyleOne />

      <PageBannerStyle1
        pageTitle={blog.length > 0 && blog[0].attributes.title}
        homePageUrl="/"
        homePageText="Home"
        activePageText={blog.length > 0 && blog[0].attributes.title}
      />

      {blog.length > 0 && <BlogDetailsContent {...blog[0]} />}

      <FooterStyleOne />
    </>
  );
};

export default BlogDetails;
