import React from "react";
import ForgetPasswordForm from "@/components/Auth/ForgetPasswordForm";

export default function ForgetPassword() {
  return (
    <>
      <ForgetPasswordForm />
    </>
  );
}
