import React from "react";
import SignUpForm from "@/components/Auth/SignUpForm";

export default function SignUp() {
  return (
    <>
      <SignUpForm />
    </>
  );
}
