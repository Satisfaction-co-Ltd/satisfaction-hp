import React from "react";
import Link from "next/link";
import Image from "next/image";
import axios from "axios";
import baseApiUrl from "@/utils/baseApiUrl";
import formatDate from "./../../utils/formatDate";

const BlogPost = () => {
  const [blogs, setBlogs] = React.useState();
  React.useEffect(() => {
    const getBlogs = async () => {
      const response = await axios.get(
        `${baseApiUrl}/api/blogs?populate=deep&sort[0]=createdAt%3Adesc`
      );
      setBlogs(response.data);
      // console.log(response.data)
    };
    getBlogs();
  }, []);

  return (
    <>
      <div className="blog-area pt-100 pb-75">
        <div className="container">
          <div className="section-title">
            <span className="sub-title">BLOG POST</span>
            <h2>Latest Article From Our Blog</h2>
          </div>

          {blogs && (
            <div className="row justify-content-center">
              {blogs.data.slice(0, 3).map((blog) => (
                <div className="col-lg-4 col-md-6" key={blog.id}>
                  <div className="single-blog-post">
                    <div className="image">
                      <Link
                        href={`/blog/${blog.attributes.slug}`}
                        className="d-block"
                      >
                        <Image
                          src={blog.attributes.image.data.attributes.url}
                          alt="blog"
                          width={865}
                          height={645}
                        />
                      </Link>

                      <span className="tag">{blog.attributes.category}</span>
                    </div>
                    <div className="content">
                      <ul className="meta">
                        <li>
                          <i className="ri-time-line"></i>
                          {formatDate(blog.attributes.createdAt)}
                        </li>
                        {/* <li>
                          <i className="ri-message-2-line"></i>
                          <Link href="#">(0) Comment</Link>
                        </li> */}
                      </ul>
                      <h3>
                        <Link href={`/blog/${blog.attributes.slug}`}>
                          {blog.attributes.title}
                        </Link>
                      </h3>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default BlogPost;
