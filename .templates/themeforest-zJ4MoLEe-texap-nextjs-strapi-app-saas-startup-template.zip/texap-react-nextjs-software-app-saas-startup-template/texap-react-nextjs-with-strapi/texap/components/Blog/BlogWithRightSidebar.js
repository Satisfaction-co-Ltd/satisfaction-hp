import React from "react";
import Link from "next/link";
import BlogSidebar from "@/components/Blog/BlogSidebar";
import Image from "next/image";
import axios from "axios";
import baseApiUrl from "@/utils/baseApiUrl";
import formatDate from "./../../utils/formatDate";

const BlogWithRightSidebar = () => {
  const [blogs, setBlogs] = React.useState();
  React.useEffect(() => {
    const getBlogs = async () => {
      const response = await axios.get(`${baseApiUrl}/api/blogs?populate=deep&sort[0]=createdAt%3Adesc`);
      setBlogs(response.data);
      // console.log(response.data)
    };
    getBlogs();
  }, []);

  return (
    <>
      <div className="blog-area ptb-100">
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-md-12">
            {blogs && (
              <div className="row justify-content-center">
                {blogs.data.map((blog) => (
                  <div className="col-lg-12 col-md-6" key={blog.id}>
                    <div className="single-blog-post">
                      <div className="image">
                        <Link href={`/blog/${blog.attributes.slug}`} className="d-block">
                          <Image
                            src={blog.attributes.image.data.attributes.url}
                            alt="blog"
                            width={865}
                            height={645}
                          />
                        </Link>
                        <span className="tag">{blog.attributes.category}</span>
                      </div>
                      <div className="content">
                        <ul className="meta">
                          <li>
                            <i className="ri-time-line"></i> {formatDate(blog.attributes.createdAt)}
                          </li>
                          {/* <li>
                            <i className="ri-message-2-line"></i>
                            <Link href="#">(0) Comment</Link>
                          </li> */}
                        </ul>
                        <h3>
                          <Link href={`/blog/${blog.attributes.slug}`}>
                            {blog.attributes.title}
                          </Link>
                        </h3>
                      </div>
                    </div>
                  </div>
                ))}
  
                {/* <div className="col-lg-12 col-md-12">
                  <div className="pagination-area">
                    <div className="nav-links">
                      <Link href="#" className="page-numbers current">
                        1
                      </Link>
                      <Link href="#" className="page-numbers">
                        2
                      </Link>
                      <Link href="#" className="page-numbers">
                        3
                      </Link>
                      <Link
                        href="#"
                        className="next page-numbers"
                        title="Next Page"
                      >
                        <i className="ri-arrow-right-line"></i>
                      </Link>
                    </div>
                  </div>
                </div> */}
              </div>
              )}
            </div>

            <div className="col-lg-4 col-md-12">
              <div className="right-sidebar">
                <BlogSidebar />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BlogWithRightSidebar;
