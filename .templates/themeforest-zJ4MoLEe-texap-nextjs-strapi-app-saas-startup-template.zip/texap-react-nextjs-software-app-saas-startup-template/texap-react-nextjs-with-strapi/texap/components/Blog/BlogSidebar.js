import React from "react";
import Link from "next/link";
import axios from "axios";
import baseApiUrl from "@/utils/baseApiUrl";
import formatDate from "./../../utils/formatDate";

const BlogSidebar = () => {
  const [blogs, setBlogs] = React.useState();
  React.useEffect(() => {
    const getBlogs = async () => {
      const response = await axios.get(`${baseApiUrl}/api/blogs?populate=*`);
      setBlogs(response.data);
    };
    getBlogs();
  }, []);

  return (
    <>
      <div className="widget-area">
        <div className="widget widget_search">
          <form className="search-form">
            <label>
              <input
                type="search"
                className="search-field"
                placeholder="Search..."
              />
            </label>
            <button type="submit">
              <i className="ri-search-2-line"></i>
            </button>
          </form>
        </div>

        {blogs && (
          <div className="widget widget_posts_thumb">
            <h3 className="widget-title">Popular Posts</h3>

            {blogs.data.slice(0, 3).map((blog) => (
              <article className="item" key={blog.id}>
                <Link href={`/blog/${blog.attributes.slug}`} className="thumb">
                  <span
                    className="fullimage cover"
                    role="img"
                    style={{
                      backgroundImage: `url(${blog.attributes.image.data.attributes.url})`,
                    }}
                  ></span>
                </Link>
                <div className="info">
                  <h4 className="title usmall">
                    <Link href={`/blog/${blog.attributes.slug}`}>
                      {blog.attributes.title}
                    </Link>
                  </h4>
                  <span className="date">
                    <i className="ri-calendar-2-fill"></i>{" "}
                    {formatDate(blog.attributes.createdAt)}
                  </span>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* <div className="widget widget_categories">
          <h3 className="widget-title">Categories</h3>

          <ul>
            <li>
              <Link href="/blog/with-right-sidebar">
                Business <span className="post-count">(2)</span>
              </Link>
            </li>
            <li>
              <Link href="/blog/with-right-sidebar">
                Privacy <span className="post-count">(5)</span>
              </Link>
            </li>
            <li>
              <Link href="/blog/with-right-sidebar">
                Technology <span className="post-count">(6)</span>
              </Link>
            </li>
            <li>
              <Link href="/blog/with-right-sidebar">
                Tips <span className="post-count">(2)</span>
              </Link>
            </li>
            <li>
              <Link href="/blog/with-right-sidebar">
                Log in <span className="post-count">(1)</span>
              </Link>
            </li>
            <li>
              <Link href="/blog/with-right-sidebar">
                Uncategorized <span className="post-count">(1)</span>
              </Link>
            </li>
          </ul>
        </div>

        <div className="widget widget_tag_cloud">
          <h3 className="widget-title">Tags</h3>

          <div className="tagcloud">
            <Link href="/blog/with-right-sidebar">Advertisment</Link>

            <Link href="/blog/with-right-sidebar">Business</Link>

            <Link href="/blog/with-right-sidebar">Life</Link>

            <Link href="/blog/with-right-sidebar">Lifestyle</Link>

            <Link href="/blog/with-right-sidebar">Fashion</Link>

            <Link href="/blog/with-right-sidebar">Ads</Link>

            <Link href="/blog/with-right-sidebar">Inspiration</Link>

            <Link href="/blog/with-right-sidebar">Blog</Link>
          </div>
        </div> */}
      </div>
    </>
  );
};

export default BlogSidebar;
