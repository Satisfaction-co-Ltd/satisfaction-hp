const formatDate = (date) => {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long', // Full month name (e.g., "April")
    day: 'numeric', // Numeric day of the month (e.g., "14")
  });
};

export default formatDate;
