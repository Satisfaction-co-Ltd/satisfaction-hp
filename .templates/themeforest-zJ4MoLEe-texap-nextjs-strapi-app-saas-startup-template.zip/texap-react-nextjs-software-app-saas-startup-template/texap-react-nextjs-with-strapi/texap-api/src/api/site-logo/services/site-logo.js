'use strict';

/**
 * site-logo service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::site-logo.site-logo');
