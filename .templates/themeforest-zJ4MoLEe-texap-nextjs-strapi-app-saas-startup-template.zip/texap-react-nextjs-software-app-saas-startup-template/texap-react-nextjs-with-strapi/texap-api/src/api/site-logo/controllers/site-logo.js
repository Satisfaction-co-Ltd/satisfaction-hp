'use strict';

/**
 * site-logo controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::site-logo.site-logo');
