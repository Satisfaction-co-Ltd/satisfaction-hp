'use strict';

/**
 * site-logo router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::site-logo.site-logo');
