'use strict';

/**
 * app-progress controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::app-progress.app-progress');
