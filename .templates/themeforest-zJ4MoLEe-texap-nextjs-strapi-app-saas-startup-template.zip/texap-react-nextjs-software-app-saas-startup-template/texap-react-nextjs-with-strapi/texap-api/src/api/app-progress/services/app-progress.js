'use strict';

/**
 * app-progress service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::app-progress.app-progress');
