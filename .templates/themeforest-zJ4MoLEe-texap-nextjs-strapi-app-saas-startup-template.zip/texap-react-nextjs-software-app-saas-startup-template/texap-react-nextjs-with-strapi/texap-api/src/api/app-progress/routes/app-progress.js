'use strict';

/**
 * app-progress router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::app-progress.app-progress');
