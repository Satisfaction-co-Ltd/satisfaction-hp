'use strict';

/**
 * top-feature service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::top-feature.top-feature');
