'use strict';

/**
 * top-feature router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::top-feature.top-feature');
