'use strict';

/**
 * top-feature controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::top-feature.top-feature');
