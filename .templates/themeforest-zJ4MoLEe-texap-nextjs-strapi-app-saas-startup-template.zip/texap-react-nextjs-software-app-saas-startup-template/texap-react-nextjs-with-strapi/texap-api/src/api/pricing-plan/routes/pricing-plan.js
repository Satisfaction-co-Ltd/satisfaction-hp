'use strict';

/**
 * pricing-plan router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::pricing-plan.pricing-plan');
