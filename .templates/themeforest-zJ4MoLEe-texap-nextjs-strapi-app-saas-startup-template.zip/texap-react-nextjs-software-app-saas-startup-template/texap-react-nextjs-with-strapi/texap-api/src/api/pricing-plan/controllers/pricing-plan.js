'use strict';

/**
 * pricing-plan controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::pricing-plan.pricing-plan');
