'use strict';

/**
 * key-feature service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::key-feature.key-feature');
