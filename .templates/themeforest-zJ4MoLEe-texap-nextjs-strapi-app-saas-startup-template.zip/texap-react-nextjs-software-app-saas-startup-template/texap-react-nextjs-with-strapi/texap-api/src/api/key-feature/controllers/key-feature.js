'use strict';

/**
 * key-feature controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::key-feature.key-feature');
