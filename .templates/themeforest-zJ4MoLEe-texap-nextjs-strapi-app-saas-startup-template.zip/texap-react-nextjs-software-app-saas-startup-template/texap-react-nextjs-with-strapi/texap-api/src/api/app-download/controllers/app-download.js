'use strict';

/**
 * app-download controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::app-download.app-download');
