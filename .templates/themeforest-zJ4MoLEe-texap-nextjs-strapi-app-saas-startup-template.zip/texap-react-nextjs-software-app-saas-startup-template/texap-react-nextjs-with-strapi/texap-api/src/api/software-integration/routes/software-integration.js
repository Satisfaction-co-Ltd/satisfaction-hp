'use strict';

/**
 * software-integration router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::software-integration.software-integration');
