'use strict';

/**
 * software-integration controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::software-integration.software-integration');
