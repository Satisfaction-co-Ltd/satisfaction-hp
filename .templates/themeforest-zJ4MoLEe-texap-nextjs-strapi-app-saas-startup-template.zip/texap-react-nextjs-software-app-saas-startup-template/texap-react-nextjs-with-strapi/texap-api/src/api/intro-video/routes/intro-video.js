'use strict';

/**
 * intro-video router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::intro-video.intro-video');
