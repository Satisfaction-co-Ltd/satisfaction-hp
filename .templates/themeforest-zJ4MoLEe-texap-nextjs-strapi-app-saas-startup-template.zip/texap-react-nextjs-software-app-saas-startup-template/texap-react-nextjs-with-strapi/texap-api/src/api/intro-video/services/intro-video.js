'use strict';

/**
 * intro-video service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::intro-video.intro-video');
