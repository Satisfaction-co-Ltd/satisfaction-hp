'use strict';

/**
 * intro-video controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::intro-video.intro-video');
