'use strict';

/**
 * client-feedback router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::client-feedback.client-feedback');
