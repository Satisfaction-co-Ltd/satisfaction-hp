'use strict';

/**
 * client-feedback controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::client-feedback.client-feedback');
