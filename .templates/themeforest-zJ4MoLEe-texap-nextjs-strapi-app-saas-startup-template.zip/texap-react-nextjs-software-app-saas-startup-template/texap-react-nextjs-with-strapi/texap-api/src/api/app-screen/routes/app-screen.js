'use strict';

/**
 * app-screen router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::app-screen.app-screen');
