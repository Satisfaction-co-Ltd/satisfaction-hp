'use strict';

/**
 * app-screen controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::app-screen.app-screen');
