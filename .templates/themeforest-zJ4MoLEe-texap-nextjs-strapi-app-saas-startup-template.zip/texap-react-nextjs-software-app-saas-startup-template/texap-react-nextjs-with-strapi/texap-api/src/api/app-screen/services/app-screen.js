'use strict';

/**
 * app-screen service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::app-screen.app-screen');
