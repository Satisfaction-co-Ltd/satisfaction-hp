module.exports = () => ({
  upload: {
    config: {
      provider: 'cloudinary',
      providerOptions: {
        cloud_name: 'mmmiah',
        api_key: '159818539864293',
        api_secret: 'r6lbW0GR7jQ2II4hCl3vGEMY-IM',
      },
      actionOptions: {
        upload: {},
        delete: {},
      },
    },
  },
});
