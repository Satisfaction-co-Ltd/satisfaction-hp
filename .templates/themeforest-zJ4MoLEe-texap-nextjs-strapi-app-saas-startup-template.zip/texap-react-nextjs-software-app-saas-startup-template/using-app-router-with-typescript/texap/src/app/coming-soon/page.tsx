import Countdown from "@/components/ComingSoon/Countdown";
import React from "react";

const ComingSoon = () => {
  return (
    <>
      <Countdown endDate="" />
    </>
  );
};

export default ComingSoon;
