import React from "react";
import SignInForm from "@/components/Auth/SignInForm";

export default function Page() {
  return (
    <>
      <SignInForm />
    </>
  );
}
