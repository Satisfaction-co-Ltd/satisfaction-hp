import React from "react";
import SignUpForm from "@/components/Auth/SignUpForm";

export default function Page() {
  return (
    <>
      <SignUpForm />
    </>
  );
}
